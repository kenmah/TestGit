dgspconfig.exe

Use this utility to create DG custom columns for SharePoint sites.

This utility will create two custom columns for those sites configured in spconfig.xml:

Column:  DGC
Column:  DGS

Usage:

Edit the provided spconfig.xml file and specify SharePoint instances and sites of interest.

Run the utility.

1.  Choose an instance to configure.
2.  Choose a site to configure.
3.  Choose a list to configure.
4.  Choose the appropriate action:
	a.  Create DG Columns (create the columns cited above from the selected site)
	b.  Delete DG Columns (delete the columns cited above from the selected site)
	c.  Verify DG Columns (determine whether or the selected site contains the columns cited above)

The following Windows SharePoint Services 3 Web Services are used by this utility:

Lists

The following methods from the Lists Web Service are used by this utility:

GetList
GetListCollection
UpdateList
